//
// SSLServerMirror
//
// Devloper tool used to help develop and verify
// HTTP Tunneling in the GME product.
//

#include <iostream>
#include <sstream>
#include <thread>
#include <chrono>
#include <queue>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <openssl/bio.h>
#include <openssl/ssl.h>
#include <openssl/err.h>

namespace {


std::ostringstream logPrefix;

std::string SSL_error_str(int sslError)
{
	    std::string sslErrorStr;

		    switch(sslError)
				    {
#define CASE_SSL_ERROR_TYPE(__k__) case __k__: sslErrorStr = #__k__;break;
		CASE_SSL_ERROR_TYPE(SSL_ERROR_NONE)
		CASE_SSL_ERROR_TYPE(SSL_ERROR_SSL)
		CASE_SSL_ERROR_TYPE(SSL_ERROR_WANT_READ)
		CASE_SSL_ERROR_TYPE(SSL_ERROR_WANT_WRITE)
		CASE_SSL_ERROR_TYPE(SSL_ERROR_WANT_X509_LOOKUP)
		CASE_SSL_ERROR_TYPE(SSL_ERROR_SYSCALL)
		CASE_SSL_ERROR_TYPE(SSL_ERROR_ZERO_RETURN)
		CASE_SSL_ERROR_TYPE(SSL_ERROR_WANT_CONNECT)
		CASE_SSL_ERROR_TYPE(SSL_ERROR_WANT_ACCEPT)

	default:
		sslErrorStr.assign("Invalid SSL_ERROR value: ") += sslError;
		break;
	}
	return sslErrorStr;
}


int server_verify_client_cert(int preverify_ok, X509_STORE_CTX *x509_ctx)
{
	std::cout << logPrefix.str() 
		<< "server_verify_client_cert: preverify_ok = " 
		<< preverify_ok
		<< std::endl;
	const EVP_MD *digest = EVP_get_digestbyname("sha1");
	unsigned char md[EVP_MAX_MD_SIZE] = {};
	unsigned int n;
	X509 *x509 = X509_STORE_CTX_get_current_cert(x509_ctx);
	X509_digest(x509, digest, md, &n);
	std::string fingerprint;
	char buff[10];

	const size_t fingerprintLastIndex = 19;
	for (size_t i = 0; i < fingerprintLastIndex; i++)
	{
		snprintf(buff, sizeof(buff), "%02X:", md[i]);
		fingerprint.append(buff);
	}
	snprintf(buff, sizeof(buff), "%02X", md[fingerprintLastIndex]);
	fingerprint.append(buff);
	std::cout << logPrefix.str() 
		<< "server_verify_client_cert: FINGERPRINT : " 
		<< fingerprint.c_str()
		<< std::endl;

	//return preverify_ok;
	return 1;
}

std::string ossl_err_as_string()
{
	BIO *bio = BIO_new (BIO_s_mem ());
	ERR_print_errors (bio);
	char *buf = NULL;
	size_t len = BIO_get_mem_data (bio, &buf);
	char *ret = (char *) calloc (1, 1 + len);
	if (ret)
	{
		memcpy (ret, buf, len);
	}
	BIO_free (bio);
	std::string result(ret);
	return result;
}


SSL_CTX *sslctx;
SSL *cSSL;

void InitializeSSL()
{
	SSL_load_error_strings();
	SSL_library_init();
	OpenSSL_add_all_algorithms();
}

void DestroySSL()
{
	ERR_free_strings();
	EVP_cleanup();
}

void ShutdownSSL()
{
	if (cSSL)
	{
		SSL_shutdown(cSSL);
		SSL_free(cSSL);
	}
}


void server(int listenPort, std::string message)
{
	logPrefix << getpid() <<  ": " << message.c_str() << " Server: ";
	std::cout << logPrefix.str() << "Start: " << message << std::endl;
	int listenFd = -1;
	int newFd = -1;
	do {
		InitializeSSL();
		listenFd = socket(AF_INET, SOCK_STREAM,0);
		if (-1 == listenFd)
		{
			std::cout << logPrefix.str() << "socket() failed?!, error = " << strerror(errno) << std::endl;
			break;
		}
		int option = 1;
		setsockopt(listenFd, SOL_SOCKET, SO_REUSEADDR, &option, sizeof(option));
		std::cout << logPrefix.str() << "listen worked, listenFd = " << listenFd << std::endl;
		struct sockaddr_in localAddr;
		const socklen_t localAddrLen = sizeof(localAddr);
		memset(&localAddr, 0, localAddrLen);
		localAddr.sin_family = AF_INET;
		localAddr.sin_port = htons(listenPort);
		localAddr.sin_addr.s_addr = htonl(INADDR_ANY);
        int result = bind(listenFd, (const struct sockaddr *)&localAddr, localAddrLen);
		if (-1 == result)
		{
			std::cout << logPrefix.str() << "bind() failed?!, error = " << strerror(errno)<< std::endl;
			break;
		}
		std::cout << logPrefix.str() << "bind() worked" << std::endl;
        result = listen(listenFd, 10);
		if (-1 == result)
		{
			std::cout << logPrefix.str() << "listen() failed?!, error = " << strerror(errno)<< std::endl;
			break;
		}
		std::cout << logPrefix.str() << "listen() worked" << std::endl;

		struct sockaddr_in remoteAddr;
		socklen_t remoteAddrLen = sizeof(remoteAddr);
		memset(&remoteAddr, 0, remoteAddrLen);
        newFd = accept(listenFd, (struct sockaddr *)&remoteAddr, &remoteAddrLen);
		if (-1 == newFd)
		{
			std::cout << logPrefix.str() << "accept() failed?!, error = " << strerror(errno)<< std::endl;
			break;
		}
		std::cout << logPrefix.str() << "accept() worked" << std::endl;

		sslctx = SSL_CTX_new(TLSv1_server_method());
		if (NULL == sslctx)
		{
			std::cout << logPrefix.str() << "SSL_CTX_new() failed?" << std::endl;
		}
		std::cout << logPrefix.str() << "SSL_CTX_new() worked" << std::endl;
		long sslOptions = SSL_OP_SINGLE_DH_USE | 
						  SSL_OP_NO_SSLv2 | 
						  SSL_OP_NO_SSLv3 |
						  SSL_OP_TLS_BLOCK_PADDING_BUG |
						  SSL_OP_DONT_INSERT_EMPTY_FRAGMENTS;
		SSL_CTX_set_options(sslctx, sslOptions);

		const char *sslCipherList = "HIGH:!DH:!ADH:!MD5:!aNULL:!eNULL:@STRENGTH";
		if (0 == SSL_CTX_set_cipher_list(sslctx, sslCipherList))
		{
			std::string errString = ossl_err_as_string();
			std::cout << logPrefix.str() << "SSL_CTX_set_cipher() failed," << errString << std::endl;
			break;
		}

		SSL_CTX_set_verify(sslctx, SSL_VERIFY_PEER|SSL_VERIFY_FAIL_IF_NO_PEER_CERT|SSL_VERIFY_CLIENT_ONCE, server_verify_client_cert);
		int use_cert = SSL_CTX_use_certificate_file(sslctx, "certs/servercert.pem", SSL_FILETYPE_PEM);
		if (1 != use_cert)
		{
			std::string errString = ossl_err_as_string();
			std::cout << logPrefix.str() << "SSL_CTX_use_certificate_file() failed," << errString << std::endl;
			break;
		}
		std::cout << logPrefix.str() << "SSL_CTX_use_certificate_file() worked" << std::endl;
		int use_key = SSL_CTX_use_PrivateKey_file(sslctx, "certs/serverkey.pem", SSL_FILETYPE_PEM);
		if (1 != use_key)
		{
			std::string errString = ossl_err_as_string();
			std::cout << logPrefix.str() << "SSL_CTX_use_PrivateKey_file() failed, " << errString << std::endl;
			break;
		}
		std::cout << logPrefix.str() << "SSL_CTX_use_PrivateKey_file() worked!" << std::endl;
		cSSL = SSL_new(sslctx);
		if (NULL == cSSL)
		{
			std::string errString = ossl_err_as_string();
			std::cout << logPrefix.str() << "SSL_new() failed" << errString << std::endl;
			break;

		}
		std::cout << logPrefix.str() << "SSL_new() worked" << std::endl;
		int sslSetFd = SSL_set_fd(cSSL, newFd);
		if (1 != sslSetFd)
		{
			std::string errString = ossl_err_as_string();
			std::cout << logPrefix.str() << "SSL_set_fd() failed, " << errString << std::endl;
			break;
		}
		std::cout << logPrefix.str() << "SSL_set_fd() worked" << std::endl;
		int sslAccept = SSL_accept(cSSL);
		if (1 != sslAccept)
		{
			int sslErr = SSL_get_error(cSSL, sslAccept);
			std::string errString = ossl_err_as_string();
			std::cout << logPrefix.str() << "SSL_accept() failed, error = "  << sslErr << " error = " << strerror(errno) << ", " << errString << std::endl;
			break;
		}
		std::cout << logPrefix.str() << "SSL_accept() worked!"  << std::endl;

		// You can do SSL_write and SSL_read now!!!
		
		
	} while(0);

	int sslReadBytes = 1;
	int sslWriteBytes = 1;
	char buff[1500];
	do {
		sslReadBytes = SSL_read(cSSL, buff, sizeof(buff));
		if (sslReadBytes > 0) 
		{
			std::cout << logPrefix.str() << "SSL_read() read "  << sslReadBytes << " Bytes" << std::endl;
			// Need to make the SSRC unique, and not a duplicate
			// Add the PID of the process to the current SSRC.  that way if the SSRC
			// should change in mid call, ours will also change with it.
			unsigned int ssrc = 0;
			memcpy(&ssrc, &buff[2 + 8], 4);
			ssrc += getpid();
			memcpy(&buff[2 + 8], &ssrc, 4);
			sslWriteBytes = SSL_write(cSSL, buff, sslReadBytes);
			if (sslWriteBytes > 0) 
			{
				std::cout << logPrefix.str() << "SSL_write() wrote "  << sslWriteBytes << " Bytes" << std::endl;
			}
			else
			{
				int sslErr = SSL_get_error(cSSL, sslWriteBytes);
				std::string sslErrStr = SSL_error_str(sslErr);
				std::string errString = ossl_err_as_string();
				std::cout << logPrefix.str() << "SSL_write() failed, error = "  << sslErrStr.c_str() << " error = " << strerror(errno) << ", " << errString << std::endl;
				if (-1 == sslWriteBytes)
				{
					if (SSL_ERROR_WANT_READ == sslErr)
					{
						std::cout << logPrefix.str() << "SSL_read() failed, SSL_ERROR_WANT_READ" << std::endl;
						sslReadBytes = 1;
						sslWriteBytes = 1;
						continue;

					}
					if (SSL_ERROR_WANT_WRITE == sslErr)
					{
						std::cout << logPrefix.str() << "SSL_read() failed, SSL_ERROR_WANT_WRITE" << std::endl;
						sslReadBytes = 1;
						sslWriteBytes = 1;
						continue;

					}
				}
				break;
			}
		}
		else
		{
			int sslErr = SSL_get_error(cSSL, sslReadBytes);
			std::string sslErrStr = SSL_error_str(sslErr);
			std::string errString = ossl_err_as_string();
			std::cout << logPrefix.str() << "SSL_read() failed, sslReadBytes = " << sslReadBytes << ", error = "  << sslErrStr.c_str() << " error = " << strerror(errno) << ", " << errString << std::endl;
			if (-1 == sslReadBytes)
			{
				if (SSL_ERROR_WANT_READ == sslErr)
				{
					std::cout << logPrefix.str() << "SSL_read() failed, SSL_ERROR_WANT_READ" << std::endl;
					sslReadBytes = 1;
					sslWriteBytes = 1;
					continue;
				}
				if (SSL_ERROR_WANT_WRITE == sslErr)
				{
					std::cout << logPrefix.str() << "SSL_read() failed, SSL_ERROR_WANT_WRITE" << std::endl;
					sslReadBytes = 1;
					sslWriteBytes = 1;
					continue;
				}
			}
			break;
		}

	} while ((sslReadBytes > 0) && (sslWriteBytes > 0));

	ShutdownSSL();
	DestroySSL();
	if (-1 != newFd)
	{
		close(newFd);
	}
	if (-1 != listenFd)
	{
		close(listenFd);
	}

	std::cout << logPrefix.str() << "End: " << message << std::endl;
}
}// namespace

int main(int argc, char **argv)
{
	int audioPort = 1114;
	int videoPort = 1611;

	std::cout << "SSL Server Mirror!" << std::endl;


	// If argc = 1, then its just the name of the exe and we should
	// use the default ports, so say that.  If it's 2, then
	// its an error, either give audio and video ports, or not at all.
	if (1 == argc)
	{
		std::cout << "Using default audio(" << audioPort << ") and video(" << videoPort << ") ports" << std::endl;
	}
	else if (2 == argc)
	{
		std::cout << "Error, need both audio and video ports." << std::endl;
	}
	else if (3 == argc)
	{
		audioPort = atoi(argv[1]);
		videoPort = atoi(argv[2]);
		std::cout << "Using provided audio(" << audioPort << ") and video(" << videoPort  << ") ports" << std::endl;
	}
	else
	{
		std::cout << "Error, too many arguments" << std::endl;
	}

	pid_t childPid = fork();
	if (0 != childPid)
	{
		std::cout << "Parent!  Child PID = " << childPid << std::endl;
		server(audioPort, "Audio");
	}
	else
	{
		std::cout << "Child!" << std::endl;
		server(videoPort, "Video");
	}

	return 0;
}

