g++ -std=c++0x -pthread -L/usr/local/Cellar/openssl/1.0.2e_1/lib/ -I/usr/local/Cellar/openssl/1.0.2e_1/include/ SSLServerMirror.cc -lssl -lcrypto -o SSLServerMirror
